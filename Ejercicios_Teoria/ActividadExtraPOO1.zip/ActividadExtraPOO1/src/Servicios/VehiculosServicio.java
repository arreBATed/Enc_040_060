
package Servicios;

import Entidades.Vehiculo;
import java.time.Year;
import java.util.Date;
import java.util.Scanner;

public class VehiculosServicio {
    
    public Vehiculo crearVehiculo()   {
        
        Vehiculo v;
        
        v = new Vehiculo();
        Scanner leer = new Scanner(System.in);
        System.out.println ("Ingrese la marca del vehiculo: ");
        v.setMarca(leer.nextLine());
        System.out.println("Ingrese la modelo del modelo: ");
        v.setModelo(leer.nextLine());
        System.out.println("Ingrese el tipo de vehiculo: ");
        v.setTipo(leer.nextLine());
        System.out.println("Ingrese la año del fabricacion: ");
        v.setAnio(leer.nextInt());
        return v;
        
    }
    
    public int moverse(Vehiculo v, int t)   {
        
        int distancia;

        switch (v.getTipo()){
            case "automovil" :  
                                distancia = 3 * t;
                                break;
            case "motocicleta" :
                                distancia = 2 * t;
                                break;
            case "bicicleta" :
                                distancia = 1 * t;
                                break;
            default:
                    distancia = 0;
                    System.out.println("No se reconoce el tipo");                                                       
        }            
        return distancia;
    }
       
    public int frenar(Vehiculo v, int t)   {
        
        int distancia;

        switch (v.getTipo()){
            case "automovil" :  
                                distancia = t + 2;
                                break;
            case "motocicleta" :
                                distancia = t + 2;
                                break;
            case "bicicleta" :
                                distancia = t + 0;
                                break;
            default:
                    distancia = 0;
                    System.out.println("No se reconoce el tipo");                                                       
        }            
        return distancia;
    }
}
