
package Entidades;


public class TiposVehiculos {
    
    
}
