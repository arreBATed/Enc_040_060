
package actividadextrapoo1;

import Entidades.Vehiculo;
import Servicios.VehiculosServicio;

public class ActividadExtraPOO1 {


    public static void main(String[] args) {
        
        VehiculosServicio vs = new VehiculosServicio();
        Vehiculo vehiculo1 = vs.crearVehiculo();
        Vehiculo vehiculo2 = vs.crearVehiculo();
        Vehiculo vehiculo3 = vs.crearVehiculo();
        
        int t = 5; 
        System.out.println("El vehiculo 1 en"+t+" seg avanzo "+vs.moverse(vehiculo1,t)+" metros.");
        System.out.println("El vehiculo 2 en"+t+" seg avanzo "+vs.moverse(vehiculo2,t)+" metros.");
        System.out.println("El vehiculo 3 en"+t+" seg avanzo "+vs.moverse(vehiculo3,t)+" metros.");
        t = 10; 
        System.out.println("El vehiculo 1 en"+t+" seg avanzo "+vs.moverse(vehiculo1,t)+" metros.");
        System.out.println("El vehiculo 2 en"+t+" seg avanzo "+vs.moverse(vehiculo2,t)+" metros.");
        System.out.println("El vehiculo 3 en"+t+" seg avanzo "+vs.moverse(vehiculo3,t)+" metros.");
        t = 60; 
        System.out.println("El vehiculo 1 en"+t+" seg avanzo "+vs.moverse(vehiculo1,t)+" metros.");
        System.out.println("El vehiculo 2 en"+t+" seg avanzo "+vs.moverse(vehiculo2,t)+" metros.");
        System.out.println("El vehiculo 3 en"+t+" seg avanzo "+vs.moverse(vehiculo3,t)+" metros.");
        
        t = 300; 
        System.out.println("El vehiculo 1 en"+t+" seg avanzo "+vs.frenar(vehiculo1,(vs.moverse(vehiculo1,t)))+" metros.");
        System.out.println("El vehiculo 2 en"+t+" seg avanzo "+vs.frenar(vehiculo2,(vs.moverse(vehiculo2,t)))+" metros.");
        System.out.println("El vehiculo 3 en"+t+" seg avanzo "+vs.frenar(vehiculo3,(vs.moverse(vehiculo3,t)))+" metros.");
        
    }  
    
}
