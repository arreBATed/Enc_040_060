
package Entities;

public class VectorMeses {
    
    private String[] mes;

    public VectorMeses() {
        
    }
    
    public VectorMeses(String[] mes) {
        this.mes = mes;
    }

    public String[] getMes() {
        return mes;
    }

    public void setMes(String[] mes) {
        this.mes = mes;
    }
    
}
