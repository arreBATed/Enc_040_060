
package ej_extra_06_juego_del_ahorcado;

public class Ej_extra_06_Juego_del_Ahorcado {

    public static void main(String[] args) {
        // TODO code application logic here
    }
    
}
